from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class Storage:
    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _init_db(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS channels (
                    chat_id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    username TEXT,
                    reference TEXT NOT NULL,
                    reactions TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    delay_min REAL NOT NULL DEFAULT 1,
                    delay_max REAL NOT NULL DEFAULT 4,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS reaction_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    reaction TEXT,
                    status TEXT NOT NULL,
                    detail TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_logs_created_at
                    ON reaction_logs(created_at DESC);
                """
            )

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def upsert_channel(
        self,
        *,
        chat_id: int,
        title: str,
        username: str | None,
        reference: str,
        reactions: list[str],
        delay_min: float,
        delay_max: float,
        enabled: bool = True,
    ) -> None:
        now = self._now()
        with self._connect() as connection:
            existing = connection.execute(
                "SELECT chat_id FROM channels WHERE chat_id = ?", (chat_id,)
            ).fetchone()
            if existing is None:
                connection.execute(
                    """
                    INSERT INTO channels (
                        chat_id, title, username, reference, reactions, enabled,
                        delay_min, delay_max, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        chat_id,
                        title,
                        username,
                        reference,
                        json.dumps(reactions, ensure_ascii=False),
                        int(enabled),
                        delay_min,
                        delay_max,
                        now,
                        now,
                    ),
                )
            else:
                connection.execute(
                    """
                    UPDATE channels
                    SET title = ?, username = ?, reference = ?, updated_at = ?
                    WHERE chat_id = ?
                    """,
                    (title, username, reference, now, chat_id),
                )

    def get_channel(self, chat_id: int) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM channels WHERE chat_id = ?", (chat_id,)
            ).fetchone()
        return self._decode_channel(row) if row else None

    def get_channels(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM channels ORDER BY title COLLATE NOCASE"
            ).fetchall()
        return [self._decode_channel(row) for row in rows]

    def remove_channel(self, chat_id: int) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM channels WHERE chat_id = ?", (chat_id,)
            )
        return cursor.rowcount > 0

    def set_reactions(self, chat_id: int, reactions: list[str]) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE channels SET reactions = ?, updated_at = ? WHERE chat_id = ?",
                (json.dumps(reactions, ensure_ascii=False), self._now(), chat_id),
            )
        return cursor.rowcount > 0

    def set_delay(self, chat_id: int, delay_min: float, delay_max: float) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE channels
                SET delay_min = ?, delay_max = ?, updated_at = ?
                WHERE chat_id = ?
                """,
                (delay_min, delay_max, self._now(), chat_id),
            )
        return cursor.rowcount > 0

    def set_enabled(self, chat_id: int, enabled: bool) -> bool:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE channels SET enabled = ?, updated_at = ? WHERE chat_id = ?",
                (int(enabled), self._now(), chat_id),
            )
        return cursor.rowcount > 0

    def add_log(
        self,
        *,
        chat_id: int,
        message_id: int,
        reaction: str | None,
        status: str,
        detail: str = "",
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO reaction_logs (
                    chat_id, message_id, reaction, status, detail, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    chat_id,
                    message_id,
                    reaction,
                    status,
                    detail[:1000],
                    self._now(),
                ),
            )

    def recent_logs(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT reaction_logs.*, channels.title
                FROM reaction_logs
                LEFT JOIN channels ON channels.chat_id = reaction_logs.chat_id
                ORDER BY reaction_logs.id DESC
                LIMIT ?
                """,
                (max(1, min(limit, 100)),),
            ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _decode_channel(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        try:
            item["reactions"] = json.loads(item["reactions"])
        except (json.JSONDecodeError, TypeError):
            item["reactions"] = []
        item["enabled"] = bool(item["enabled"])
        return item
