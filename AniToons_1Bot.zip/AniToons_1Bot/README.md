# AniToons_1Bot

Telegram channel join + reaction manager.

This project uses two Telegram sessions:

1. **Admin bot session** — receives private admin commands.
2. **User session** — performs channel joins and reactions through Telegram's MTProto API.

A normal Telegram Bot API bot cannot join a channel by itself, so the channel-joining/reaction worker is intentionally a Telegram user session.

## Features

- Join public channels and supported invite links with `/join`
- Add already-joined channels with `/addchannel`
- Automatically react to new channel posts
- Configure one or more normal emoji reactions per channel
- Randomly choose a configured reaction
- Configure a random delay before reacting
- Pause/resume individual channels
- Test the reaction on the latest post
- SQLite persistence and activity logs
- Admin-only command access
- Docker support
- GitHub Actions syntax/compile check

## Telegram requirements

You need:

- A Telegram bot token from **@BotFather**
- A Telegram **API ID** and **API hash** from https://my.telegram.org
- A Telegram user account session string for the worker account
- Your Telegram numeric user ID for admin access

Keep the bot token, API hash, and especially the user session string private. Never commit a real `.env` file or session string.

## Setup

### 1. Generate the user session

Install dependencies:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\\Scripts\\activate

pip install -r requirements.txt
```

Run:

```bash
python session_generator.py
```

Complete Telegram's login/2FA prompts. Copy the printed `USER_SESSION` value into your environment.

### 2. Configure environment variables

Copy `.env.example` to `.env` and fill in:

```env
API_ID=123456
API_HASH=your_api_hash
BOT_TOKEN=123456:ABC...
USER_SESSION=your_telethon_string_session
ADMIN_USER_ID=123456789
DB_PATH=data/bot.sqlite3
DEFAULT_REACTIONS=❤️,🔥,👍
DEFAULT_DELAY_MIN=1
DEFAULT_DELAY_MAX=4
```

### 3. Start

```bash
python bot.py
```

The first run creates the SQLite database under `data/`.

## Admin commands

Commands must be sent to the control bot from the configured `ADMIN_USER_ID`.

```text
/start
/help
/status
/join <channel or invite>
/addchannel <channel> [emoji]
/setreaction <channel> <emoji1,emoji2,...>
/setdelay <channel> <min> <max>
/pause <channel>
/resume <channel>
/remove <channel>
/channels
/test <channel>
/logs
```

### Example

```text
/join @AniToonsChannel
/setreaction @AniToonsChannel ❤️,🔥
/setdelay @AniToonsChannel 2 5
```

After configuration, the worker watches for new posts in the configured Telegram channels and sends a configured reaction after the selected delay.

## Important behavior

- The worker reacts only to channels that are explicitly stored in the database and enabled.
- Group/supergroup messages are ignored; the target must be a Telegram channel.
- Bots cannot send paid reactions through the Bot API; this project uses normal emoji reactions.
- Reaction availability is controlled by Telegram/channel settings. A reaction may fail if that emoji is not allowed.
- Join and reaction activity is performed by the configured user account, not the admin bot account.
- Use the worker only with channels/accounts you control or are authorized to operate.

## Docker

```bash
docker build -t anitoons-1bot .
docker run --env-file .env -v "$(pwd)/data:/app/data" anitoons-1bot
```

## Project structure

```text
AniToons_1Bot/
├── bot.py
├── config.py
├── storage.py
├── session_generator.py
├── requirements.txt
├── Dockerfile
├── .env.example
├── .gitignore
└── .github/
    └── workflows/
        └── ci.yml
```
