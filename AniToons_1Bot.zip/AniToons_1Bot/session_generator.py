from __future__ import annotations

import asyncio
import os

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession


async def main() -> None:
    load_dotenv()
    api_id_raw = os.getenv("API_ID", "").strip()
    api_hash = os.getenv("API_HASH", "").strip()

    if not api_id_raw or not api_hash:
        raise SystemExit("Set API_ID and API_HASH in .env before running this script.")

    try:
        api_id = int(api_id_raw)
    except ValueError as exc:
        raise SystemExit("API_ID must be an integer.") from exc

    client = TelegramClient(StringSession(), api_id, api_hash)
    try:
        await client.start()
        print("\nUSER_SESSION=" + client.session.save())
        print("\nStore this value as a secret. Do not commit it to GitHub.")
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
