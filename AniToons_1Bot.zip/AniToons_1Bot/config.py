from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _int(name: str) -> int:
    try:
        return int(_required(name))
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc


def _float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    try:
        return float(value)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a number") from exc


@dataclass(frozen=True)
class Settings:
    api_id: int
    api_hash: str
    bot_token: str
    user_session: str
    admin_user_id: int
    db_path: str
    default_reactions: tuple[str, ...]
    default_delay_min: float
    default_delay_max: float


def load_settings() -> Settings:
    reactions = tuple(
        item.strip()
        for item in os.getenv("DEFAULT_REACTIONS", "❤️,🔥,👍").split(",")
        if item.strip()
    ) or ("❤️",)

    delay_min = _float("DEFAULT_DELAY_MIN", 1.0)
    delay_max = _float("DEFAULT_DELAY_MAX", 4.0)

    if delay_min < 0 or delay_max < 0:
        raise RuntimeError("DEFAULT_DELAY_MIN/MAX cannot be negative")
    if delay_min > delay_max:
        raise RuntimeError("DEFAULT_DELAY_MIN cannot be greater than DEFAULT_DELAY_MAX")

    return Settings(
        api_id=_int("API_ID"),
        api_hash=_required("API_HASH"),
        bot_token=_required("BOT_TOKEN"),
        user_session=_required("USER_SESSION"),
        admin_user_id=_int("ADMIN_USER_ID"),
        db_path=os.getenv("DB_PATH", "data/bot.sqlite3").strip() or "data/bot.sqlite3",
        default_reactions=reactions,
        default_delay_min=delay_min,
        default_delay_max=delay_max,
    )
