from __future__ import annotations

import asyncio
import logging
import random
import re

from telethon import TelegramClient, errors, events, functions, types
from telethon.sessions import MemorySession, StringSession

from config import load_settings
from storage import Storage

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
LOGGER = logging.getLogger("anitoons")

settings = load_settings()
storage = Storage(settings.db_path)

admin_client = TelegramClient(MemorySession(), settings.api_id, settings.api_hash)
worker_client = TelegramClient(
    StringSession(settings.user_session),
    settings.api_id,
    settings.api_hash,
)

INVITE_RE = re.compile(
    r"^(?:https?://)?t\.me/(?:\+|joinchat/)([A-Za-z0-9_-]+)$",
    re.IGNORECASE,
)
USERNAME_RE = re.compile(
    r"^(?:https?://)?t\.me/([A-Za-z0-9_]{4,})/?$",
    re.IGNORECASE,
)


def normalize_ref(value: str) -> str:
    value = value.strip()
    if value.startswith("@"):
        return value
    match = USERNAME_RE.match(value)
    if match:
        return "@" + match.group(1)
    return value


def parse_reactions(value: str) -> list[str]:
    reactions = [item.strip() for item in value.split(",") if item.strip()]
    if not reactions:
        raise ValueError("At least one emoji reaction is required.")
    if any(len(item) > 32 for item in reactions):
        raise ValueError("A reaction value is unexpectedly long.")
    return reactions


def is_admin(event: events.NewMessage.Event) -> bool:
    return bool(event.is_private and event.sender_id == settings.admin_user_id)


async def reply(event: events.NewMessage.Event, text: str) -> None:
    await event.reply(text)


async def get_channel_entity(reference: str) -> types.Channel:
    entity = await worker_client.get_entity(normalize_ref(reference))
    if not isinstance(entity, types.Channel):
        raise ValueError("That target is not a Telegram channel.")
    return entity


async def save_entity(
    entity: types.Channel,
    reference: str,
    *,
    reactions: list[str] | None = None,
) -> int:
    chat_id = worker_client.get_peer_id(entity)
    existing = storage.get_channel(chat_id)
    if reactions is None:
        reactions = (
            existing["reactions"]
            if existing and existing["reactions"]
            else list(settings.default_reactions)
        )

    delay_min = (
        float(existing["delay_min"])
        if existing is not None
        else settings.default_delay_min
    )
    delay_max = (
        float(existing["delay_max"])
        if existing is not None
        else settings.default_delay_max
    )

    storage.upsert_channel(
        chat_id=chat_id,
        title=getattr(entity, "title", "(untitled channel)"),
        username=getattr(entity, "username", None),
        reference=reference,
        reactions=reactions,
        delay_min=delay_min,
        delay_max=delay_max,
        enabled=existing["enabled"] if existing else True,
    )
    if existing is not None and reactions is not None:
        storage.set_reactions(chat_id, reactions)
    return chat_id


async def resolve_and_join(reference: str) -> types.Channel:
    reference = reference.strip()
    invite_match = INVITE_RE.match(reference)

    if invite_match:
        invite_hash = invite_match.group(1)
        result = await worker_client(
            functions.messages.ImportChatInviteRequest(hash=invite_hash)
        )
        channels = [
            chat
            for chat in getattr(result, "chats", [])
            if isinstance(chat, types.Channel)
        ]
        if not channels:
            raise ValueError("The invite was accepted, but no channel was returned.")
        return channels[0]

    entity = await get_channel_entity(reference)
    try:
        await worker_client(functions.channels.JoinChannelRequest(channel=entity))
    except errors.UserAlreadyParticipantError:
        pass
    return entity


async def react_to_message(
    *,
    entity: types.Channel,
    message_id: int,
    reaction: str,
) -> None:
    await worker_client(
        functions.messages.SendReactionRequest(
            peer=entity,
            msg_id=message_id,
            reaction=[types.ReactionEmoji(emoticon=reaction)],
        )
    )


async def handle_channel_post(event: events.NewMessage.Event) -> None:
    if event.out or not getattr(event.message, "post", False):
        return

    chat_id = event.chat_id
    if chat_id is None:
        return

    config = storage.get_channel(chat_id)
    if not config or not config["enabled"]:
        return

    try:
        entity = await event.get_chat()
        if not isinstance(entity, types.Channel) or getattr(entity, "megagroup", False):
            return

        delay = random.uniform(float(config["delay_min"]), float(config["delay_max"]))
        if delay:
            await asyncio.sleep(delay)

        reactions = config["reactions"] or list(settings.default_reactions)
        reaction = random.choice(reactions)
        await react_to_message(entity=entity, message_id=event.message.id, reaction=reaction)

        storage.add_log(
            chat_id=chat_id,
            message_id=event.message.id,
            reaction=reaction,
            status="success",
        )
        LOGGER.info(
            "Reacted %s to %s message %s",
            reaction,
            config["title"],
            event.message.id,
        )
    except errors.FloodWaitError as exc:
        storage.add_log(
            chat_id=chat_id,
            message_id=event.message.id,
            reaction=None,
            status="flood_wait",
            detail=f"Telegram requested a wait of {exc.seconds}s.",
        )
        LOGGER.warning("Flood wait for %ss on chat %s", exc.seconds, chat_id)
    except errors.RPCError as exc:
        storage.add_log(
            chat_id=chat_id,
            message_id=event.message.id,
            reaction=None,
            status="error",
            detail=str(exc),
        )
        LOGGER.warning("Reaction failed on %s/%s: %s", chat_id, event.message.id, exc)
    except Exception as exc:
        storage.add_log(
            chat_id=chat_id,
            message_id=event.message.id,
            reaction=None,
            status="error",
            detail=repr(exc),
        )
        LOGGER.exception("Unexpected reaction failure")


async def command_handler(event: events.NewMessage.Event) -> None:
    if not is_admin(event):
        return

    raw = (event.raw_text or "").strip()
    if not raw.startswith("/"):
        return

    parts = raw.split(maxsplit=3)
    command = parts[0].split("@", 1)[0].lower()
    args = parts[1:]

    try:
        if command in {"/start", "/help"}:
            await reply(
                event,
                "AniToons_1Bot\n\n"
                "Commands:\n"
                "/status\n"
                "/channels\n"
                "/join <channel or invite>\n"
                "/addchannel <channel> [emoji]\n"
                "/setreaction <channel> <emoji1,emoji2,...>\n"
                "/setdelay <channel> <min> <max>\n"
                "/pause <channel>\n"
                "/resume <channel>\n"
                "/remove <channel>\n"
                "/test <channel>\n"
                "/logs",
            )
            return

        if command == "/status":
            bot_me = await admin_client.get_me()
            worker_me = await worker_client.get_me()
            count = len(storage.get_channels())
            await reply(
                event,
                "Status: ONLINE\n"
                f"Admin bot: @{getattr(bot_me, 'username', None) or 'unknown'}\n"
                f"Worker: {getattr(worker_me, 'first_name', '')} "
                f"(@{getattr(worker_me, 'username', None) or 'no_username'})\n"
                f"Configured channels: {count}",
            )
            return

        if command == "/channels":
            channels = storage.get_channels()
            if not channels:
                await reply(event, "No channels are configured yet.")
                return

            lines = []
            for item in channels:
                username = f"@{item['username']}" if item["username"] else item["reference"]
                state = "ON" if item["enabled"] else "OFF"
                lines.append(
                    f"{state} {item['title']} ({username})\n"
                    f"   reactions: {', '.join(item['reactions'])}\n"
                    f"   delay: {item['delay_min']}–{item['delay_max']}s"
                )
            await reply(event, "\n\n".join(lines))
            return

        if command == "/join":
            if not args:
                raise ValueError("Usage: /join <@channelusername or invite link>")
            reference = args[0]
            entity = await resolve_and_join(reference)
            chat_id = await save_entity(entity, reference)
            reactions = storage.get_channel(chat_id)["reactions"]
            await reply(
                event,
                f"Joined/configured: {getattr(entity, 'title', 'channel')}\n"
                f"Reactions: {', '.join(reactions)}",
            )
            return

        if command == "/addchannel":
            if not args:
                raise ValueError("Usage: /addchannel <channel> [emoji]")
            reference = args[0]
            entity = await get_channel_entity(reference)
            reactions = parse_reactions(args[1]) if len(args) >= 2 else None
            await save_entity(entity, reference, reactions=reactions)
            await reply(event, f"Configured: {getattr(entity, 'title', 'channel')}")
            return

        if command == "/setreaction":
            if len(args) < 2:
                raise ValueError("Usage: /setreaction <channel> <emoji1,emoji2,...>")
            entity = await get_channel_entity(args[0])
            reactions = parse_reactions(args[1])
            chat_id = worker_client.get_peer_id(entity)
            if not storage.set_reactions(chat_id, reactions):
                raise ValueError("That channel is not configured. Use /addchannel or /join first.")
            await reply(event, f"Reactions updated: {', '.join(reactions)}")
            return

        if command == "/setdelay":
            if len(args) < 3:
                raise ValueError("Usage: /setdelay <channel> <min_seconds> <max_seconds>")
            entity = await get_channel_entity(args[0])
            delay_min = float(args[1])
            delay_max = float(args[2])
            if delay_min < 0 or delay_max < 0 or delay_min > delay_max:
                raise ValueError("Delay must satisfy 0 <= min <= max.")
            chat_id = worker_client.get_peer_id(entity)
            if not storage.set_delay(chat_id, delay_min, delay_max):
                raise ValueError("That channel is not configured yet.")
            await reply(event, f"Delay updated to {delay_min:g}–{delay_max:g} seconds.")
            return

        if command in {"/pause", "/resume"}:
            if not args:
                raise ValueError(f"Usage: {command} <channel>")
            entity = await get_channel_entity(args[0])
            chat_id = worker_client.get_peer_id(entity)
            enabled = command == "/resume"
            if not storage.set_enabled(chat_id, enabled):
                raise ValueError("That channel is not configured yet.")
            await reply(event, f"{getattr(entity, 'title', 'Channel')}: {'ON' if enabled else 'OFF'}")
            return

        if command == "/remove":
            if not args:
                raise ValueError("Usage: /remove <channel>")
            entity = await get_channel_entity(args[0])
            chat_id = worker_client.get_peer_id(entity)
            removed = storage.remove_channel(chat_id)
            await reply(
                event,
                "Removed from reaction monitoring." if removed else "That channel was not configured.",
            )
            return

        if command == "/test":
            if not args:
                raise ValueError("Usage: /test <channel>")
            entity = await get_channel_entity(args[0])
            chat_id = worker_client.get_peer_id(entity)
            config = storage.get_channel(chat_id)
            if not config:
                raise ValueError("That channel is not configured.")
            messages = await worker_client.get_messages(entity, limit=1)
            if not messages:
                raise ValueError("No post was found in that channel.")
            message = messages[0]
            if not getattr(message, "post", False):
                raise ValueError("The latest message is not a channel post.")
            reaction = random.choice(config["reactions"])
            await react_to_message(entity=entity, message_id=message.id, reaction=reaction)
            storage.add_log(
                chat_id=chat_id,
                message_id=message.id,
                reaction=reaction,
                status="manual_test",
            )
            await reply(event, f"Test reaction sent: {reaction}")
            return

        if command == "/logs":
            logs = storage.recent_logs(20)
            if not logs:
                await reply(event, "No reaction logs yet.")
                return
            lines = []
            for item in logs:
                name = item.get("title") or str(item["chat_id"])
                reaction = item.get("reaction") or "-"
                lines.append(
                    f"{item['created_at']} | {name} | "
                    f"msg {item['message_id']} | {item['status']} | {reaction}"
                )
            await reply(event, "\n".join(lines))
            return

        await reply(event, "Unknown command. Use /help.")
    except errors.FloodWaitError as exc:
        await reply(event, f"Telegram requested a wait of {exc.seconds} seconds. Try again later.")
    except errors.RPCError as exc:
        await reply(event, f"Telegram error: {type(exc).__name__}: {exc}")
    except (ValueError, IndexError) as exc:
        await reply(event, f"Error: {exc}")
    except Exception as exc:
        LOGGER.exception("Command failed")
        await reply(event, f"Unexpected error: {type(exc).__name__}")


async def main() -> None:
    await admin_client.start(bot_token=settings.bot_token)
    await worker_client.connect()

    if not await worker_client.is_user_authorized():
        raise RuntimeError(
            "USER_SESSION is not authorized. Generate a fresh StringSession with session_generator.py."
        )

    bot_me = await admin_client.get_me()
    worker_me = await worker_client.get_me()
    LOGGER.info(
        "Admin bot connected as @%s; worker connected as %s",
        getattr(bot_me, "username", None),
        getattr(worker_me, "username", None),
    )

    admin_client.add_event_handler(command_handler, events.NewMessage(incoming=True))
    worker_client.add_event_handler(handle_channel_post, events.NewMessage(incoming=True))

    await asyncio.gather(
        admin_client.run_until_disconnected(),
        worker_client.run_until_disconnected(),
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        LOGGER.info("Stopped by user")
